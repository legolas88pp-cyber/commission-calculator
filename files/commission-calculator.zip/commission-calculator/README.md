# Commission Calculator

A mobile-first commission calculator for agents.

## How to Deploy (Step-by-Step)

### Step 1: Create a GitHub Account
1. Go to https://github.com
2. Click "Sign Up"
3. Enter your email, create a password, choose a username
4. Verify your email

### Step 2: Create a Vercel Account
1. Go to https://vercel.com
2. Click "Sign Up"
3. Choose "Continue with GitHub"
4. Authorize Vercel to access your GitHub

### Step 3: Upload This Project to GitHub
1. Log into GitHub
2. Click the "+" icon in the top right corner
3. Click "New repository"
4. Name it: `commission-calculator`
5. Keep it as "Public" (or Private if you prefer)
6. Click "Create repository"
7. On the next page, click "uploading an existing file"
8. Drag and drop ALL the files and folders from this project
   - Make sure to include: package.json, vite.config.js, tailwind.config.js, postcss.config.js, index.html, and the entire src/ folder
9. Click "Commit changes"

### Step 4: Deploy on Vercel
1. Go to https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. Find your `commission-calculator` repository and click "Import"
4. Leave all settings as default (Vercel auto-detects Vite)
5. Click "Deploy"
6. Wait about 60 seconds
7. Done! Vercel gives you a link like: `commission-calculator-xxxx.vercel.app`

### Step 5: Share the Link
- Copy the Vercel link
- Share it with your agents via Viber, Messenger, or text
- It works on any phone browser — no app install needed

### Optional: Custom Project Name
- In Vercel, go to Settings → General → Project Name
- Change it to something shorter
- Your link becomes: `your-name.vercel.app`

## Tech Stack
- React 18
- Vite 5
- Tailwind CSS 3
- Hosted on Vercel (free tier)
